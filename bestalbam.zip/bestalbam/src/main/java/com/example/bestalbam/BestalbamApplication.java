package com.example.bestalbam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BestalbamApplication {

	public static void main(String[] args) {
		SpringApplication.run(BestalbamApplication.class, args);
	}

}
